package com.example.auth.dto;

import jakarta.validation.constraints.NotBlank;

public record LoginInput(
        @NotBlank String username,
        @NotBlank String password
) {
}
