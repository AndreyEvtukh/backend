package com.example.auth.graphql;

import com.example.auth.entity.User;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;

@Controller
public class UserResolver {

    @QueryMapping
    @PreAuthorize("isAuthenticated()")
    public User me(@AuthenticationPrincipal User currentUser) {
        // currentUser сюда попадает благодаря JwtAuthenticationFilter, который кладёт
        // User (реализует UserDetails) в SecurityContext как principal.
        // Если токен отсутствует/невалиден — @PreAuthorize бросит AccessDeniedException
        // ещё до вызова метода, и GraphQlExceptionHandler превратит это в ошибку UNAUTHENTICATED.
        return currentUser;
    }
}
