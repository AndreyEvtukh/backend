package com.example.auth.exception;

import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.graphql.execution.DataFetcherExceptionResolverAdapter;
import org.springframework.graphql.execution.ErrorType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class GraphQlExceptionHandler extends DataFetcherExceptionResolverAdapter {

    @Override
    protected GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        if (ex instanceof ApplicationException appEx) {
            return buildError(appEx.getMessage(), appEx.getErrorCode(), ErrorType.BAD_REQUEST, env);
        }
        if (ex instanceof AuthenticationException) {
            return buildError("Authentication required", "UNAUTHENTICATED", ErrorType.UNAUTHORIZED, env);
        }
        if (ex instanceof AccessDeniedException) {
            // @PreAuthorize("isAuthenticated()") в Spring Security 6 бросает единый
            // AccessDeniedException и для анонимного, и для аутентифицированного-но-без-прав
            // случая. Различаем их вручную, чтобы не путать клиента 403 там, где на
            // самом деле нужен 401 (нет/невалиден токен).
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            boolean isAnonymous = auth == null || auth instanceof AnonymousAuthenticationToken;
            if (isAnonymous) {
                return buildError("Authentication required", "UNAUTHENTICATED", ErrorType.UNAUTHORIZED, env);
            }
            return buildError("Access denied", "FORBIDDEN", ErrorType.FORBIDDEN, env);
        }
        // неизвестные ошибки не раскрываем клиенту подробно — только generic-сообщение,
        // полный stacktrace уходит в лог сервера
        return null;
    }

    private GraphQLError buildError(String message, String code, ErrorType type, DataFetchingEnvironment env) {
        return GraphqlErrorBuilder.newError(env)
                .message(message)
                .errorType(type)
                .extensions(java.util.Map.of("code", code))
                .build();
    }
}
