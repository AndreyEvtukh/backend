package com.example.auth.service;

import com.example.auth.dto.AuthPayload;
import com.example.auth.dto.LoginInput;
import com.example.auth.dto.RegisterInput;
import com.example.auth.entity.Role;
import com.example.auth.entity.User;
import com.example.auth.exception.InvalidCredentialsException;
import com.example.auth.exception.UserAlreadyExistsException;
import com.example.auth.repository.UserRepository;
import com.example.auth.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Transactional
    public AuthPayload register(RegisterInput input) {
        if (userRepository.existsByUsername(input.username())) {
            throw new UserAlreadyExistsException("Username is already taken: " + input.username());
        }
        if (userRepository.existsByEmail(input.email())) {
            throw new UserAlreadyExistsException("Email is already registered: " + input.email());
        }

        User user = new User();
        user.setUsername(input.username());
        user.setEmail(input.email());
        user.setPasswordHash(passwordEncoder.encode(input.password()));
        user.setRole(Role.USER);

        User saved = userRepository.save(user);
        return issueTokenFor(saved);
    }

    @Transactional(readOnly = true)
    public AuthPayload login(LoginInput input) {
        User user = userRepository.findByUsername(input.username())
                .orElseThrow(InvalidCredentialsException::new);

        if (!passwordEncoder.matches(input.password(), user.getPasswordHash())) {
            throw new InvalidCredentialsException();
        }
        if (!user.isEnabled()) {
            throw new InvalidCredentialsException();
        }

        return issueTokenFor(user);
    }

    private AuthPayload issueTokenFor(User user) {
        String token = jwtService.generateAccessToken(user.getId(), user.getUsername(), user.getRole().name());
        return AuthPayload.of(token, jwtService.getAccessTokenTtlSeconds(), user);
    }
}
