package com.example.auth.dto;

import com.example.auth.entity.User;

public record AuthPayload(
        String accessToken,
        String tokenType,
        int expiresInSeconds,
        User user
) {
    public static AuthPayload of(String accessToken, long expiresInSeconds, User user) {
        return new AuthPayload(accessToken, "Bearer", (int) expiresInSeconds, user);
    }
}
