package com.example.auth.exception;

public class InvalidCredentialsException extends ApplicationException {

    public InvalidCredentialsException() {
        super("Invalid username or password", "INVALID_CREDENTIALS");
    }
}
