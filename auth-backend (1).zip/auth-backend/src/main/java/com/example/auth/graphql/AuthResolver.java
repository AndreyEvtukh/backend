package com.example.auth.graphql;

import com.example.auth.dto.AuthPayload;
import com.example.auth.dto.LoginInput;
import com.example.auth.dto.RegisterInput;
import com.example.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.validation.annotation.Validated;
import org.springframework.stereotype.Controller;

@Controller
@Validated
@RequiredArgsConstructor
public class AuthResolver {

    private final AuthService authService;

    @MutationMapping
    public AuthPayload register(@Argument @Valid RegisterInput input) {
        return authService.register(input);
    }

    @MutationMapping
    public AuthPayload login(@Argument @Valid LoginInput input) {
        return authService.login(input);
    }
}
