# auth-backend

Spring Boot + Spring for GraphQL + Spring Security (JWT) + PostgreSQL.

## Запуск

1. Поднять БД:
   ```bash
   docker compose up -d
   ```

2. Задать секрет JWT (обязательно случайная строка ≥ 32 байт, храните вне репозитория):
   ```bash
   export JWT_SECRET="$(openssl rand -base64 48)"
   ```

3. Запустить приложение:
   ```bash
   ./mvnw spring-boot:run
   ```

Приложение поднимется на `http://localhost:8080/graphql`. Flyway применит миграцию из
`src/main/resources/db/migration/V1__init.sql` автоматически при старте.

GraphiQL (веб-интерфейс для тестовых запросов) доступен на `http://localhost:8080/graphiql`.

## Переменные окружения

| Переменная              | По умолчанию              | Назначение                          |
|--------------------------|---------------------------|--------------------------------------|
| `DB_HOST`                | `localhost`                | хост PostgreSQL                     |
| `DB_PORT`                | `5432`                     | порт PostgreSQL                     |
| `DB_NAME`                | `auth_db`                  | имя БД                              |
| `DB_USER`                | `auth_user`                 | пользователь БД                     |
| `DB_PASSWORD`            | `auth_password`             | пароль БД                           |
| `JWT_SECRET`              | dev-заглушка (см. код)     | **обязательно** переопределить в проде |
| `JWT_ACCESS_TTL_MIN`      | `15`                        | время жизни access-токена, минуты   |
| `CORS_ALLOWED_ORIGINS`    | `http://localhost:4200`     | origin вашего Angular-приложения    |
| `SERVER_PORT`             | `8080`                      | порт HTTP-сервера                   |

## Примеры GraphQL-запросов

### Регистрация

```graphql
mutation {
  register(input: { username: "john", email: "john@example.com", password: "SuperSecret1" }) {
    accessToken
    tokenType
    expiresInSeconds
    user { id username email role }
  }
}
```

### Логин

```graphql
mutation {
  login(input: { username: "john", password: "SuperSecret1" }) {
    accessToken
    user { id username email role }
  }
}
```

### Текущий пользователь (защищённый запрос)

Требует заголовок `Authorization: Bearer <accessToken>`, полученный из `register`/`login`.

```graphql
query {
  me { id username email role }
}
```

curl-пример:

```bash
curl http://localhost:8080/graphql \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <accessToken>" \
  -d '{"query":"query { me { id username email role } }"}'
```

## Как это устроено

- **JWT, а не сессии**: `JwtService` подписывает токен алгоритмом HS256, `JwtAuthenticationFilter`
  на каждом запросе проверяет заголовок `Authorization` и, если токен валиден, кладёт
  `User` (реализует `UserDetails`) в `SecurityContext`.
- **Один HTTP-эндпоинт `/graphql` для всех операций** — поэтому разграничение
  "публичная/защищённая" операция сделано не на уровне HTTP (там всё `permitAll`),
  а на уровне резолверов через `@PreAuthorize("isAuthenticated()")` (см. `UserResolver.me`).
- **Пароли** хранятся только как BCrypt-хэш (`passwordHash`), поле не входит в GraphQL-схему
  `User`, поэтому наружу никогда не отдаётся, даже случайно.
- **Ошибки** (неверный пароль, занятый username, отсутствие токена) превращаются
  в структурированные GraphQL-ошибки с `extensions.code` через `GraphQlExceptionHandler`,
  а не в 500/стектрейс.
- **Миграции схемы БД** через Flyway (`V1__init.sql`) — не полагаемся на
  `hibernate.ddl-auto=update`, чтобы схема была предсказуемой и версионируемой.

## Интеграция с Angular (FE)

Отдельно от этого бэкенда: на фронте отправляйте GraphQL-запросы на `/graphql` (через Apollo
Angular или обычный `HttpClient`), сохраняйте `accessToken` (например, в памяти/сервисе, не в
`localStorage`, если критична защита от XSS) и добавляйте его в заголовок `Authorization: Bearer
<token>` для запросов, требующих авторизации. Если нужно — могу отдельно расписать этот слой
(Apollo Client setup, auth interceptor/link, hранение токена, refresh-логику) в следующем шаге.
