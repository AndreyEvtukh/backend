package com.example.demograph.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;

/**
 * ВНИМАНИЕ: соответствие полей столбцам таблицы "users" в Supabase — предположение,
 * так как реальная схема таблицы не была предоставлена. Перед запуском сверьте
 * имена столбцов (id, email, name, created_at) с фактической структурой таблицы
 * и поправьте аннотации @Column при необходимости.
 */
@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
public class User {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "email")
    private String email;

    @Column(name = "name")
    private String name;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;
}
